
let numbers = [10, 25, 8, 32, 3, 19];
let min = numbers[0];
for (let i = 1; i < numbers.length; i++) {
  if (numbers[i] < min) {
    min = numbers[i]; 
  }
}
document.getElementById("result").innerHTML = "Minimum number is: " + min;

